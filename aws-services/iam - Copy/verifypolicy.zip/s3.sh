aws s3api create-bucket --bucket bubucke --region ap-south-1 --create-bucket-configuration LocationConstraint=ap-south-1

