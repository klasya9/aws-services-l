aws iam create-policy --policy-name S3ListBucketPolicy --policy-document file://s3.json


