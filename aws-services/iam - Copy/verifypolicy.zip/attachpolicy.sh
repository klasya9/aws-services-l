aws iam attach-user-policy --user-name iamcliuser_A --policy-arn arn:aws:iam::928775835336:policy/S3ListBucketPolicy
