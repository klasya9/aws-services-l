aws iam list-policies --query "Policies[?PolicyName=='S3ListBucketPolicy'].Arn" --output text
